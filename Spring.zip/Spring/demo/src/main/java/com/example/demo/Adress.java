package com.example.demo;

//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service(value="lADS")
public class Adress
{

	public String getBuildName()
	{
		return "Hotel Taj";
	}
}
